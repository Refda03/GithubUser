package com.rehza.myapplication.datauser.model

data class User(
    val login: String,
    val id: Int,
    val avatar_url: String
)